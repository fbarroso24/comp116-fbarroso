<!DOCTYPE html>

<html>
<head>
<title>Login</title>
<link rel="stylesheet" type="text/css" href="yui.2.css" />
<link rel="stylesheet" type="text/css" href="global.6.css" />
</head>
<body>
<form method="post" action="login.php">
<p>Login <input type="text" name="login" size="15" maxlength="15"></p>
<p>Password <input type="password" name="password" size="15"></p>
<p><input type="submit" value="Submit"> <input type="reset"></p>
</form>
</body>
</html>

